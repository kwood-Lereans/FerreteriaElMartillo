
const express = require("express");
const mysql = require("mysql2"); 
const app = express();

app.set("view engine", "ejs");

// 1. IMPORTANTE: Indicamos a Express dónde buscar los archivos CSS estáticos
app.use(express.static("public"));

// 2. IMPORTANTE: Habilitamos el procesamiento de datos del formulario HTML
app.use(express.urlencoded({extended:false}));
app.use(express.json());

// Conexión a la Base de Datos
let Conexion = mysql.createConnection({
    host: "localhost",
    database: "formulario",
    user: "root",
    password: ""
});

// Ruta Inicial: Carga la vista de la encuesta
app.get("/", function(req, res){
    res.render("registro");
});

// Ruta POST: Captura las respuestas del usuario y las guarda en phpMyAdmin
app.post("/enviar", function(req, res){
    // Extraemos el valor numérico (1 al 5) seleccionado en cada pregunta
    const { p1, p2, p3, p4, p5, p6, p7, p8, p9, p10 } = req.body;
    
    // Consulta SQL para insertar los registros
    const sql = "INSERT INTO respuestas_encuesta (p1, p2, p3, p4, p5, p6, p7, p8, p9, p10) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
    
    Conexion.query(sql, [p1, p2, p3, p4, p5, p6, p7, p8, p9, p10], function(err, result){
        if(err){
            console.log("Error al insertar los datos: ", err);
            return res.send("Ocurrió un error al guardar la encuesta.");
        }
        // Mensaje de éxito en el navegador tras guardar la encuesta
        res.send("<h1>¡Encuesta guardada con éxito en la Base de Datos!</h1><a href='/'>Volver a responder</a>");
    });
});

// Levantar el servidor
app.listen(3000, function(){
    console.log("Servidor creado http://localhost:3000");
});